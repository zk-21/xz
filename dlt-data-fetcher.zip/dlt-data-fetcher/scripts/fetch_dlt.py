"""
大乐透开奖数据抓取工具
从中国体彩官方 API (webapi.sporttery.cn) 获取历史开奖数据，
生成 all_draws.js（JS格式）和 1.xlsx（Excel详细报表）。

用法:
    python fetch_dlt.py [--periods N] [--output DIR]
    
    --periods N   抓取期数，默认 500
    --output DIR  输出目录，默认当前目录
"""
import requests
import json
import time
import os
import sys
import argparse
import datetime
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ============================================================
# 配置
# ============================================================
BASE_URL = "https://webapi.sporttery.cn/gateway/lottery/getHistoryPageListV1.qry"
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Host": "webapi.sporttery.cn",
    "Accept": "application/json, text/plain, */*",
    "Referer": "https://www.lottery.gov.cn/",
}
PAGE_SIZE = 30  # API 每页条数
GAME_NO = 85    # 彩种: 85=大乐透
WEEKDAYS = ["一", "二", "三", "四", "五", "六", "日"]

# ============================================================
# API 数据获取
# ============================================================

def fetch_page(page_no, page_size=PAGE_SIZE):
    """获取一页开奖数据"""
    params = {
        "gameNo": GAME_NO,
        "provinceId": 0,
        "pageSize": page_size,
        "isVerify": 1,
        "pageNo": page_no,
    }
    try:
        resp = requests.get(BASE_URL, params=params, headers=HEADERS,
                          verify=False, timeout=20)
        if resp.status_code == 200:
            data = resp.json()
            if data.get("success") and data.get("value"):
                items = data["value"].get("list", [])
                total = data["value"].get("total", 0)
                return items, total
            else:
                print(f"  [WARN] API返回异常: {data.get('errorMessage', '未知')}")
        else:
            print(f"  [WARN] HTTP {resp.status_code}")
    except Exception as e:
        print(f"  [ERROR] 请求失败: {e}")
    return [], 0


def fetch_all(target_count):
    """抓取指定数量的历史数据"""
    all_items = []
    pages_needed = (target_count + PAGE_SIZE - 1) // PAGE_SIZE
    print(f"开始抓取 {target_count} 期 (共 {pages_needed} 页)...")

    for page in range(1, pages_needed + 1):
        items, total = fetch_page(page)
        if not items:
            print(f"  第 {page} 页为空，停止")
            break
        all_items.extend(items)
        print(f"  第 {page} 页: {len(items)} 条, 累计 {len(all_items)} 条")
        if len(all_items) >= target_count:
            break
        if page < pages_needed:
            time.sleep(0.3)
    return all_items

# ============================================================
# 数据解析
# ============================================================

def parse_item(item):
    """解析单条API返回数据为结构化记录"""
    result = item.get("lotteryDrawResult", "") or item.get("lotteryUnsortDrawresult", "")
    if not result:
        return None

    nums = result.strip().split()
    if len(nums) < 7:
        return None

    front = sorted(int(n) for n in nums[:5])
    back = sorted(int(n) for n in nums[5:7])
    draw_time = (item.get("lotteryDrawTime") or item.get("lotterySaleEndtime") or "")[:10]

    # 星期几
    weekday = ""
    if draw_time:
        try:
            weekday = WEEKDAYS[datetime.datetime.strptime(draw_time, "%Y-%m-%d").weekday()]
        except ValueError:
            pass

    # 奖金详情
    prizes = {}
    for p in item.get("prizeLevelList", []):
        name = p.get("prizeLevel", "")
        prizes[name] = {
            "count": p.get("stakeCount", ""),
            "amount": p.get("stakeAmount", ""),
            "addCount": p.get("addStakeCount", ""),
            "addAmount": p.get("addStakeAmount", ""),
        }

    return {
        "issue": item.get("lotteryDrawNum", ""),
        "date": draw_time,
        "weekday": weekday,
        "front": front,
        "back": back,
        "front_str": ",".join(f"{n:02d}" for n in front),
        "back_str": ",".join(f"{n:02d}" for n in back),
        "prizes": prizes,
        "totalSales": item.get("totalSales", ""),
        "poolBalanceAfterdraw": item.get("poolBalanceAfterdraw", ""),
    }


def dedup_and_sort(items):
    """去重并升序排列"""
    seen = set()
    unique = []
    for d in items:
        if d["issue"] not in seen:
            seen.add(d["issue"])
            unique.append(d)
    unique.sort(key=lambda x: x["issue"])
    return unique

# ============================================================
# 文件生成: all_draws.js
# ============================================================

def generate_js(draws, output_dir):
    """生成 all_draws.js 文件"""
    path = os.path.join(output_dir, "all_draws.js")
    now = time.strftime("%Y-%m-%d %H:%M:%S")
    lines = [
        f"// 大乐透历史开奖数据 (自动生成)",
        f"// 共 {len(draws)} 期 | 范围 {draws[0]['issue']} ~ {draws[-1]['issue']}",
        f"// 下载时间: {now} | 数据来源: webapi.sporttery.cn",
        "const ALL_DRAWS = [",
    ]
    for d in reversed(draws):  # 降序写入
        lines.append(
            f'  {{issue:"{d["issue"]}", date:"{d["date"]}", '
            f'front:[{",".join(str(n) for n in d["front"])}], '
            f'back:[{",".join(str(n) for n in d["back"])}], '
            f'front_str:"{d["front_str"]}", back_str:"{d["back_str"]}"}},'
        )
    lines += [
        "];",
        "",
        "// 升序排列 (旧→新)",
        "ALL_DRAWS.sort((a, b) => a.issue.localeCompare(b.issue));",
        "",
        "if (typeof module !== 'undefined') module.exports = { ALL_DRAWS };",
    ]
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    print(f"  ✅ all_draws.js  ({len(draws)} 期)")
    return path

# ============================================================
# 文件生成: 1.xlsx
# ============================================================

def generate_xlsx(draws, output_dir):
    """生成 1.xlsx 详细开奖报表"""
    try:
        import openpyxl
    except ImportError:
        print("  ⚠️  缺少 openpyxl，正在安装...")
        import subprocess
        subprocess.check_call([sys.executable, "-m", "pip", "install", "openpyxl", "-q"])
        import openpyxl

    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter

    path = os.path.join(output_dir, "1.xlsx")
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "大乐透开奖数据"

    headers = [
        "期号", "开奖时间", "周",
        "前区一", "前区二", "前区三", "前区四", "前区五",
        "后区一", "后区二",
        "一等奖基本注数", "一等奖基本金额", "一等奖追加注数", "一等奖追加奖金",
        "二等奖基本注数", "二等奖基本金额", "二等奖追加注数", "二等奖追加奖金",
        "三等奖注数", "三等奖金额",
        "四等奖注数", "四等奖金额",
        "五等奖注数", "五等奖金额",
        "六等奖注数", "六等奖金额",
        "销售额", "奖池金额",
    ]

    # 样式
    hdr_fill = PatternFill("solid", fgColor="4472C4")
    hdr_font = Font(bold=True, size=11, color="FFFFFF")
    hdr_align = Alignment(horizontal="center", vertical="center", wrap_text=True)
    data_align = Alignment(horizontal="center", vertical="center")
    thin_border = Border(
        left=Side(style="thin"), right=Side(style="thin"),
        top=Side(style="thin"), bottom=Side(style="thin"),
    )
    front_font = Font(bold=True, color="0000FF")
    back_font = Font(bold=True, color="FF0000")

    # 表头
    for col, h in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=h)
        cell.font = hdr_font
        cell.fill = hdr_fill
        cell.alignment = hdr_align
        cell.border = thin_border

    # 数据行 (降序: 最新在上)
    for row_idx, d in enumerate(reversed(draws), 2):
        row = [
            d["issue"], d["date"], d["weekday"],
            d["front"][0], d["front"][1], d["front"][2], d["front"][3], d["front"][4],
            d["back"][0], d["back"][1],
        ]
        prizes = d.get("prizes", {})
        for lvl in ["一等奖", "一等奖-追加", "二等奖", "二等奖-追加", "三等奖", "四等奖", "五等奖", "六等奖"]:
            if lvl == "一等奖-追加":
                p = prizes.get("一等奖", {})
                row += [p.get("addCount", ""), p.get("addAmount", "")]
            else:
                p = prizes.get(lvl, {})
                row += [p.get("count", ""), p.get("amount", "")]
        row += [d.get("totalSales", ""), d.get("poolBalanceAfterdraw", "")]

        for col, val in enumerate(row, 1):
            cell = ws.cell(row=row_idx, column=col, value=val)
            cell.alignment = data_align
            cell.border = thin_border
            if 4 <= col <= 8:
                cell.font = front_font
            elif 9 <= col <= 10:
                cell.font = back_font

    # 列宽
    widths = [8, 14, 5, 8, 8, 8, 8, 8, 8, 8,
              14, 14, 14, 14, 14, 14, 14, 14,
              12, 12, 12, 12, 12, 12, 12, 12, 16, 16]
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w

    ws.auto_filter.ref = ws.dimensions
    ws.freeze_panes = "A2"
    wb.save(path)
    print(f"  ✅ 1.xlsx       ({len(draws)} 行 × {len(headers)} 列)")
    return path

# ============================================================
# 主入口
# ============================================================

def main():
    parser = argparse.ArgumentParser(description="大乐透历史开奖数据抓取工具")
    parser.add_argument("--periods", type=int, default=500,
                       help="抓取期数 (默认 500)")
    parser.add_argument("--output", type=str, default=".",
                       help="输出目录 (默认当前目录)")
    args = parser.parse_args()

    print("=" * 60)
    print("  大乐透开奖数据抓取工具")
    print("  数据来源: webapi.sporttery.cn (中国体彩官方)")
    print("=" * 60)

    # 1. 抓取
    raw_items = fetch_all(args.periods)

    # 2. 解析
    draws = []
    for item in raw_items:
        d = parse_item(item)
        if d:
            draws.append(d)
    draws = dedup_and_sort(draws)

    if not draws:
        print("\n❌ 未获取到任何数据!")
        sys.exit(1)

    print(f"\n📊 共 {len(draws)} 期  ({draws[0]['issue']} ~ {draws[-1]['issue']})")
    print(f"📅 {draws[0]['date']} ~ {draws[-1]['date']}")

    # 3. 生成文件
    out_dir = os.path.abspath(args.output)
    os.makedirs(out_dir, exist_ok=True)
    print(f"\n📁 输出目录: {out_dir}")

    generate_js(draws, out_dir)
    generate_xlsx(draws, out_dir)

    # 4. 最近 5 期预览
    print(f"\n{'─' * 50}")
    print("最近 5 期:")
    for d in draws[-5:]:
        f_str = " ".join(f"{n:02d}" for n in d["front"])
        b_str = " ".join(f"{n:02d}" for n in d["back"])
        print(f"  {d['issue']} | {d['date']} | {f_str} | {b_str}")

    print(f"\n✅ 完成!")

if __name__ == "__main__":
    main()
