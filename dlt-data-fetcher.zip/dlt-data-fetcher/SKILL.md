---
name: 大乐透数据下载
description: >
  从中国体彩官方 API 下载大乐透历史开奖数据, 生成 all_draws.js (JavaScript 数组格式)
  和 1.xlsx (Excel 详细报表, 含奖金/销售额/奖池). 当用户需要下载/更新/获取大乐透开奖号码、
  生成 all_draws.js、生成开奖 Excel 报表、或任何涉及大乐透历史数据获取时使用本技能.
  TRIGGER: 大乐透, 开奖号码, 开奖数据, 下载开奖, all_draws.js, 开奖Excel, 彩票数据,
  体彩数据, DLT, da le tou, lottery data.
---

# 大乐透数据下载

## 概述

从中国体彩官方 API (`webapi.sporttery.cn`) 抓取大乐透历史开奖数据，自动生成两种格式的文件：

| 输出文件 | 格式 | 内容 |
|----------|------|------|
| `all_draws.js` | JavaScript | 期号、日期、前区[5]、后区[2]，可供预测系统直接引用 |
| `1.xlsx` | Excel | 完整开奖报表：号码 + 一等奖到六等奖注数金额 + 销售额 + 奖池 |

## 使用方法

### 基本用法（500期）

```bash
python scripts/fetch_dlt.py
```

### 指定期数和输出目录

```bash
python scripts/fetch_dlt.py --periods 120 --output ./output/
```

### 命令行参数

| 参数 | 默认值 | 说明 |
|------|--------|------|
| `--periods N` | 500 | 抓取最近 N 期 |
| `--output DIR` | `.` (当前目录) | 输出文件保存路径 |

## 数据来源

- **API**: `https://webapi.sporttery.cn/gateway/lottery/getHistoryPageListV1.qry`
- **彩种代码**: `gameNo=85` (大乐透)
- **需要请求头**: `User-Agent`, `Referer: https://www.lottery.gov.cn/`, `Host: webapi.sporttery.cn`

## 执行流程

1. **抓取**: 分页调用官方 API，每页 30 条，直到达到指定期数
2. **解析**: 提取期号、日期、前区(5个)/后区(2个)号码、奖金详情
3. **去重排序**: 按期号去重后升序排列
4. **生成 all_draws.js**: 降序写入 JS 数组，末尾代码自动排序为升序
5. **生成 1.xlsx**: 带格式的 Excel 报表（蓝底白字表头、前区蓝字、后区红字）

## 依赖

首次运行会自动安装 `openpyxl`（Excel 生成所需）。其余为标准库。

## 输出示例

### all_draws.js
```javascript
const ALL_DRAWS = [
  {issue:"26084", date:"2026-07-27", front:[13,25,30,32,33], back:[4,5], front_str:"13,25,30,32,33", back_str:"04,05"},
  ...
];
ALL_DRAWS.sort((a, b) => a.issue.localeCompare(b.issue)); // 升序
```

### 1.xlsx
| 期号 | 开奖时间 | 前区一到五 | 后区一到二 | 一等奖到六等奖 | 销售额 | 奖池金额 |
|------|----------|-----------|-----------|--------------|--------|----------|

(28列完整报表，带筛选和冻结表头)

## 注意事项

- API 有访问频率限制，脚本内置 0.3 秒延迟
- 抓取 500 期约需 10-15 秒
- 数据与官网实时同步，延迟不超过 1 天
