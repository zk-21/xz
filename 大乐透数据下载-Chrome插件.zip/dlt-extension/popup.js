// ============================================================
// 大乐透数据下载 - Chrome 扩展主逻辑
// ============================================================

const API_URL = 'https://webapi.sporttery.cn/gateway/lottery/getHistoryPageListV1.qry';
const PAGE_SIZE = 30;
const WEEKDAYS = ['日', '一', '二', '三', '四', '五', '六'];

// 状态管理
let isRunning = false;

// ============================================================
// UI 交互
// ============================================================

document.addEventListener('DOMContentLoaded', () => {
  // 预设按钮
  document.querySelectorAll('.preset').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.preset').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById('periods').value = btn.dataset.periods;
    });
  });

  // 下载按钮
  document.getElementById('btn-download').addEventListener('click', startDownload);
});

function setStatus(type, text) {
  const el = document.getElementById('status');
  const icon = document.getElementById('status-icon');
  const textEl = document.getElementById('status-text');
  el.className = `status ${type}`;
  icon.textContent = type === 'loading' ? '⏳' : type === 'success' ? '✅' : type === 'error' ? '❌' : '';
  textEl.textContent = text;
}

function setProgress(percent) {
  const bar = document.getElementById('progress-bar');
  const fill = document.getElementById('progress-fill');
  bar.classList.remove('hidden');
  fill.style.width = `${Math.min(percent, 100)}%`;
}

function setButtonState(running) {
  isRunning = running;
  const btn = document.getElementById('btn-download');
  const btnText = document.getElementById('btn-text');
  btn.disabled = running;
  btnText.textContent = running ? '下载中...' : '开始下载';
  if (running) {
    btn.querySelector('.btn-icon').innerHTML = '<span class="spinner"></span>';
  } else {
    btn.querySelector('.btn-icon').textContent = '⬇';
  }
}

// ============================================================
// 数据抓取
// ============================================================

async function fetchPage(pageNo) {
  const params = new URLSearchParams({
    gameNo: 85,
    provinceId: 0,
    pageSize: PAGE_SIZE,
    isVerify: 1,
    pageNo: pageNo,
  });

  const resp = await fetch(`${API_URL}?${params}`, {
    headers: {
      'Accept': 'application/json',
      'Referer': 'https://www.lottery.gov.cn/',
    },
  });

  if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
  const data = await resp.json();
  if (!data.success) throw new Error(data.errorMessage || 'API返回异常');
  return data.value.list || [];
}

async function fetchAll(targetCount, onProgress) {
  const allItems = [];
  const pagesNeeded = Math.ceil(targetCount / PAGE_SIZE);

  for (let page = 1; page <= pagesNeeded; page++) {
    const items = await fetchPage(page);
    allItems.push(...items);
    const pct = Math.min((page / pagesNeeded) * 60, 60); // 前60%给抓取
    onProgress(pct, `正在抓取第 ${page}/${pagesNeeded} 页...`);
    if (allItems.length >= targetCount) break;
    if (page < pagesNeeded) await sleep(200);
  }

  return allItems;
}

function parseItems(rawItems) {
  const draws = [];
  for (const item of rawItems) {
    const result = item.lotteryDrawResult || item.lotteryUnsortDrawresult || '';
    const nums = result.trim().split(/\s+/);
    if (nums.length < 7) continue;

    const front = nums.slice(0, 5).map(Number).sort((a, b) => a - b);
    const back = nums.slice(5, 7).map(Number).sort((a, b) => a - b);
    const drawTime = (item.lotteryDrawTime || item.lotterySaleEndtime || '').substring(0, 10);

    let weekday = '';
    if (drawTime) {
      const d = new Date(drawTime);
      if (!isNaN(d)) weekday = WEEKDAYS[d.getDay()];
    }

    // 奖金信息
    const prizes = {};
    for (const p of (item.prizeLevelList || [])) {
      prizes[p.prizeLevel] = {
        count: p.stakeCount || '',
        amount: p.stakeAmount || '',
        addCount: p.addStakeCount || '',
        addAmount: p.addStakeAmount || '',
      };
    }

    draws.push({
      issue: item.lotteryDrawNum || '',
      date: drawTime,
      weekday,
      front,
      back,
      front_str: front.map(n => String(n).padStart(2, '0')).join(','),
      back_str: back.map(n => String(n).padStart(2, '0')).join(','),
      prizes,
      totalSales: item.totalSales || '',
      poolBalanceAfterdraw: item.poolBalanceAfterdraw || '',
    });
  }

  // 去重 + 升序
  const seen = new Set();
  const unique = [];
  for (const d of draws) {
    if (!seen.has(d.issue)) {
      seen.add(d.issue);
      unique.push(d);
    }
  }
  unique.sort((a, b) => a.issue.localeCompare(b.issue));
  return unique;
}

// ============================================================
// 文件生成
// ============================================================

function generateJS(draws) {
  const lines = [
    `// 大乐透历史开奖数据`,
    `// 共 ${draws.length} 期 | ${draws[0].issue} ~ ${draws[draws.length - 1].issue}`,
    `// 下载时间: ${new Date().toLocaleString('zh-CN')}`,
    `// 数据来源: webapi.sporttery.cn`,
    `const ALL_DRAWS = [`,
  ];
  for (let i = draws.length - 1; i >= 0; i--) {
    const d = draws[i];
    lines.push(`  {issue:"${d.issue}", date:"${d.date}", front:[${d.front.join(',')}], back:[${d.back.join(',')}], front_str:"${d.front_str}", back_str:"${d.back_str}"},`);
  }
  lines.push(`];`);
  lines.push(``);
  lines.push(`// 升序排列 (旧->新)`);
  lines.push(`ALL_DRAWS.sort((a, b) => a.issue.localeCompare(b.issue));`);
  lines.push(``);
  lines.push(`if (typeof module !== 'undefined') module.exports = { ALL_DRAWS };`);
  return lines.join('\n');
}

function generateXLSX(draws) {
  const headers = [
    '期号', '开奖时间', '周',
    '前区一', '前区二', '前区三', '前区四', '前区五',
    '后区一', '后区二',
    '一等奖基本注数', '一等奖基本金额', '一等奖追加注数', '一等奖追加奖金',
    '二等奖基本注数', '二等奖基本金额', '二等奖追加注数', '二等奖追加奖金',
    '三等奖注数', '三等奖金额',
    '四等奖注数', '四等奖金额',
    '五等奖注数', '五等奖金额',
    '六等奖注数', '六等奖金额',
    '销售额', '奖池金额',
  ];

  const rows = [headers];

  // 降序排列
  for (let i = draws.length - 1; i >= 0; i--) {
    const d = draws[i];
    const p = d.prizes || {};
    const row = [
      d.issue, d.date, d.weekday,
      d.front[0], d.front[1], d.front[2], d.front[3], d.front[4],
      d.back[0], d.back[1],
      (p['一等奖'] || {}).count || '', (p['一等奖'] || {}).amount || '',
      (p['一等奖'] || {}).addCount || '', (p['一等奖'] || {}).addAmount || '',
      (p['二等奖'] || {}).count || '', (p['二等奖'] || {}).amount || '',
      (p['二等奖'] || {}).addCount || '', (p['二等奖'] || {}).addAmount || '',
      (p['三等奖'] || {}).count || '', (p['三等奖'] || {}).amount || '',
      (p['四等奖'] || {}).count || '', (p['四等奖'] || {}).amount || '',
      (p['五等奖'] || {}).count || '', (p['五等奖'] || {}).amount || '',
      (p['六等奖'] || {}).count || '', (p['六等奖'] || {}).amount || '',
      d.totalSales || '', d.poolBalanceAfterdraw || '',
    ];
    rows.push(row);
  }

  return rows;
}

// ============================================================
// 下载触发
// ============================================================

function downloadFile(content, filename, mimeType) {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function showPreview(draws) {
  const preview = document.getElementById('preview');
  const table = document.getElementById('preview-table');
  preview.classList.remove('hidden');

  let html = '';
  const recent = draws.slice(-5).reverse();
  for (const d of recent) {
    html += `<div class="preview-row">`;
    html += `<span class="preview-issue">${d.issue}</span>`;
    html += `<span class="preview-date">${d.date}</span>`;
    html += `<span class="preview-nums">`;
    for (const n of d.front) {
      html += `<span class="num-ball front">${String(n).padStart(2,'0')}</span>`;
    }
    html += `<span class="preview-sep">+</span>`;
    for (const n of d.back) {
      html += `<span class="num-ball back">${String(n).padStart(2,'0')}</span>`;
    }
    html += `</span></div>`;
  }
  table.innerHTML = html;
}

// ============================================================
// 主流程
// ============================================================

async function startDownload() {
  if (isRunning) return;

  const periods = parseInt(document.getElementById('periods').value) || 500;
  const wantJS = document.getElementById('fmt-js').checked;
  const wantXLSX = document.getElementById('fmt-xlsx').checked;

  if (!wantJS && !wantXLSX) {
    setStatus('error', '请至少选择一种输出格式');
    return;
  }

  // 重置UI
  setButtonState(true);
  setProgress(0);
  setStatus('loading', '正在连接中国体彩官方API...');
  document.getElementById('preview').classList.add('hidden');

  try {
    // 1. 抓取数据
    const rawItems = await fetchAll(periods, (pct, msg) => {
      setProgress(pct);
      setStatus('loading', msg);
    });

    // 2. 解析
    setProgress(65);
    setStatus('loading', '正在解析数据...');
    const draws = parseItems(rawItems);

    if (draws.length === 0) {
      throw new Error('未获取到任何数据');
    }

    // 3. 生成文件
    setProgress(80);
    setStatus('loading', '正在生成文件...');

    const timestamp = new Date().toISOString().slice(0, 10).replace(/-/g, '');

    if (wantJS) {
      const jsContent = generateJS(draws);
      downloadFile(jsContent, 'all_draws.js', 'application/javascript');
    }

    if (wantXLSX) {
      const rows = generateXLSX(draws);
      MiniXLSX.download(rows, '1.xlsx', true);
    }

    // 4. 完成
    setProgress(100);
    const files = [];
    if (wantJS) files.push('all_draws.js');
    if (wantXLSX) files.push('1.xlsx');
    setStatus('success', `完成! ${draws.length} 期 (${draws[0].issue}~${draws[draws.length-1].issue})，已生成 ${files.join('、')}`);

    showPreview(draws);

  } catch (err) {
    setProgress(0);
    setStatus('error', `下载失败: ${err.message}`);
  } finally {
    setButtonState(false);
    setTimeout(() => setProgress(0), 1500);
  }
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
